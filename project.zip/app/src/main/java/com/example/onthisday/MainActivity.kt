package com.example.onthisday

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

/** Tiny launcher screen that tells the user how to add the widget. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        setContentView(TextView(this).apply {
            setPadding(pad, pad * 2, pad, pad)
            textSize = 18f
            text = getString(R.string.setup_instructions)
        })
    }
}
