package com.example.onthisday

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

private const val LANG = "en" // change to "de", "fr", "es", ... for other Wikipedias
private val ENDPOINTS = listOf(
    "https://$LANG.wikipedia.org/api/rest_v1/feed/onthisday/events/%02d/%02d",
    "https://api.wikimedia.org/feed/v1/wikipedia/$LANG/onthisday/events/%02d/%02d"
)
private const val USER_AGENT = "OnThisDayWidget/1.0 (https://github.com/avalonava/wikiwidget-)"

private const val PREFS = "on_this_day"
private const val KEY_DATE = "date"       // yyyy-MM-dd the cached events belong to
private const val KEY_EVENTS = "events"   // JSON array of {year, text, url}
private const val KEY_INDEX = "index"
private const val KEY_ERROR = "error"
private const val KEY_ERROR_MSG = "error_msg"

private const val ACTION_NEXT = "com.example.onthisday.NEXT"
private const val ACTION_PREV = "com.example.onthisday.PREV"
private const val ACTION_REFRESH = "com.example.onthisday.REFRESH"

class OnThisDayWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        render(context)                                   // show cached content right away
        refresh(context, force = false, pending = goAsync())
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_NEXT -> step(context, +1)
            ACTION_PREV -> step(context, -1)
            ACTION_REFRESH -> refresh(context, force = true, pending = goAsync())
        }
    }
}

// ---------- data ----------

private fun prefs(context: Context): SharedPreferences =
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

private fun todayKey(): String =
    SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

private fun cachedEvents(context: Context): JSONArray? =
    prefs(context).getString(KEY_EVENTS, null)?.let { runCatching { JSONArray(it) }.getOrNull() }
        ?.takeIf { it.length() > 0 }

/** Fetches today's events on a background thread, then re-renders. Safe to call from a receiver. */
private fun refresh(context: Context, force: Boolean, pending: BroadcastReceiver.PendingResult?) {
    val app = context.applicationContext
    thread {
        try {
            val p = prefs(app)
            val fresh = p.getString(KEY_DATE, null) == todayKey() && cachedEvents(app) != null
            if (fresh && !force) return@thread

            try {
                val events = fetchEvents()
                if (events.length() == 0) error("No events returned")
                p.edit()
                    .putString(KEY_DATE, todayKey())
                    .putString(KEY_EVENTS, events.toString())
                    .putInt(KEY_INDEX, (0 until events.length()).random())
                    .putBoolean(KEY_ERROR, false)
                    .apply()
            } catch (e: Exception) {
                p.edit()
                    .putBoolean(KEY_ERROR, true)
                    .putString(KEY_ERROR_MSG, "${e.javaClass.simpleName}: ${e.message.orEmpty()}".take(120))
                    .apply()
            }
            render(app)
        } finally {
            pending?.finish()
        }
    }
}

private fun fetchEvents(): JSONArray {
    val cal = Calendar.getInstance()
    val month = cal.get(Calendar.MONTH) + 1
    val day = cal.get(Calendar.DAY_OF_MONTH)
    var last: Exception? = null
    for (template in ENDPOINTS) {
        try {
            return fetchFrom(String.format(Locale.US, template, month, day))
        } catch (e: Exception) {
            last = e
        }
    }
    throw last ?: IllegalStateException("No endpoint")
}

private fun fetchFrom(address: String): JSONArray {
    val conn = URL(address).openConnection() as HttpURLConnection
    try {
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        conn.setRequestProperty("User-Agent", USER_AGENT)
        if (conn.responseCode != HttpURLConnection.HTTP_OK) error("HTTP ${conn.responseCode}")

        val body = conn.inputStream.bufferedReader().use { it.readText() }
        val src = JSONObject(body).getJSONArray("events")
        val out = JSONArray()
        for (i in 0 until src.length()) {
            val e = src.getJSONObject(i)
            val link = e.optJSONArray("pages")
                ?.optJSONObject(0)
                ?.optJSONObject("content_urls")
                ?.optJSONObject("mobile")
                ?.optString("page")
                .orEmpty()
            out.put(
                JSONObject()
                    .put("year", e.optInt("year"))
                    .put("text", e.optString("text"))
                    .put("url", link)
            )
        }
        return out
    } finally {
        conn.disconnect()
    }
}

private fun step(context: Context, delta: Int) {
    val events = cachedEvents(context) ?: return
    val p = prefs(context)
    val n = events.length()
    p.edit().putInt(KEY_INDEX, ((p.getInt(KEY_INDEX, 0) + delta) % n + n) % n).apply()
    render(context)
}

// ---------- rendering ----------

private fun render(context: Context) {
    val manager = AppWidgetManager.getInstance(context)
    val ids = manager.getAppWidgetIds(ComponentName(context, OnThisDayWidget::class.java))
    if (ids.isEmpty()) return

    val p = prefs(context)
    val events = cachedEvents(context)
    val views = RemoteViews(context.packageName, R.layout.widget_on_this_day)

    // Header date comes from the cached data so it always matches what's shown.
    val date = p.getString(KEY_DATE, null)
        ?.let { runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(it) }.getOrNull() }
        ?: Date()
    val dateLabel = SimpleDateFormat("MMMM d", Locale.getDefault()).format(date)
    views.setTextViewText(R.id.title, context.getString(R.string.widget_title, dateLabel))

    if (events != null) {
        val e = events.getJSONObject(p.getInt(KEY_INDEX, 0).coerceIn(0, events.length() - 1))
        val year = e.optInt("year")
        views.setTextViewText(R.id.year, if (year < 0) "${-year} BC" else year.toString())
        views.setTextViewText(R.id.text, e.optString("text"))
        views.setViewVisibility(R.id.nav, View.VISIBLE)

        val url = e.optString("url")
        if (url.isNotEmpty()) {
            val open = articleIntent(context, url)
            views.setOnClickPendingIntent(
                R.id.content,
                PendingIntent.getActivity(context, 0, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            )
        }
    } else {
        views.setTextViewText(R.id.year, "")
        val failed = p.getBoolean(KEY_ERROR, false)
        val message = if (failed) {
            context.getString(R.string.widget_error) + "\n" + p.getString(KEY_ERROR_MSG, "").orEmpty()
        } else {
            context.getString(R.string.widget_loading)
        }
        views.setTextViewText(R.id.text, message)
        views.setViewVisibility(R.id.nav, View.INVISIBLE)
    }

    views.setOnClickPendingIntent(R.id.btn_prev, broadcast(context, ACTION_PREV, 1))
    views.setOnClickPendingIntent(R.id.btn_next, broadcast(context, ACTION_NEXT, 2))
    views.setOnClickPendingIntent(R.id.btn_refresh, broadcast(context, ACTION_REFRESH, 3))

    manager.updateAppWidget(ids, views)
}

private const val WIKIPEDIA_APP = "org.wikipedia"

/** Opens the article in the Wikipedia app if it's installed, otherwise in the default browser. */
private fun articleIntent(context: Context, url: String): Intent {
    val base = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    val inApp = Intent(base).setPackage(WIKIPEDIA_APP)
    return if (inApp.resolveActivity(context.packageManager) != null) inApp else base
}

private fun broadcast(context: Context, action: String, requestCode: Int): PendingIntent {
    val intent = Intent(context, OnThisDayWidget::class.java).setAction(action)
    return PendingIntent.getBroadcast(
        context, requestCode, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
